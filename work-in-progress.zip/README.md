# WorkInProgress

Demo made with clojure quil and Prossesing

To run, run lein script with 'lein run', firsttime will download deps
 
